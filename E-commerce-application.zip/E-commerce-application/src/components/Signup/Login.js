// import React, { Component } from 'react';
// import { Redirect } from 'react-router-dom';

// export default class Login extends Component{
//     constructor(props){
//         super(props)
//         const token = localStorage.getItem("token")
        
//         let loggedIn = true
//         if(token == null){
//             loggedIn = false
//         }
//         this.state={
//             username:"",
//             password:"",
//             loggedIn
//         }
//         this.onChange=this.onChange.bind(this)
//         this.submitForm=this.submitForm.bind(this)
//     }
//     onChange(e){
//         this.setState({
//             [e.target.name]:e.target.value
//         })
//     }
//     submitForm(e){
//         e.preventDefault()
//         const{ username, password } =  this.state
//         if(username==="A" && password === "B"){
//             localStorage.setItem("token","abcdefgh")
//             this.setState({
//                 loggedIn:true
//             })
//         }

//     }
//     render(){
//         if(this.state.loggedIn){
//             return <Redirect to="/"/>
//         }
//         return(
//             <div>
//                 <h1>Login</h1>
//                 <form onSubmit={this.submitForm}>
//                     <input type='text' placeholder='username' name='username' value={this.state.username} onChange={this.onChange}/>
//                     <br/>
//                     <input type='text' placeholder='password' name='password' value={this.state.password} onChange={this.onChange}/>
//                     <br/>
//                     <input type='submit'/>
//                     <br/>

//                 </form>

//             </div>

//         )
//     }
// }












import React, { useState,useEffect } from 'react';
import {useHistory} from "react-router-dom";
import './Login.css'
import { Link } from 'react-router-dom';

export default function Login(){
    
    const [emailid,setEmail]=useState("");
    const [password,setPassword]=useState("");
    const history=useHistory();
    useEffect(()=>{
        if(localStorage.getItem('user-info')){
            history.push("/login")
        }
    },[])
    async function login()
    {
        console.warn(emailid,password)
        let item={emailid,password};
        let result=await fetch("http://localhost:8080/login",{
            method:'POST',
            headers:{
               "Content-Type":"application/json",
               "Accept":'application/json'
            },
            body:JSON.stringify(item)
        });
        result=await result.json()
        localStorage.setItem("user-info",JSON.stringify(result))
        history.push("/")
    }
   
    return(
        <div>         
               <div className='loginwidth'><br></br>
                   <h1 className='regi'>Login</h1>
                   <br/>
                 <br/>
                        <div className='col-sm-6 offset-sm-3'>
                        <input type="text" placeholder='username'
                        onChange={(e)=>setEmail(e.target.value)}
                         className="form-control"/>
                        <br/>
                        <input type="password" placeholder='password' 
                         onChange={(e)=>setPassword(e.target.value)}
                        className="form-control"/>
                        <br/>

                        <button onClick={login} className="btn btn-primary">Login</button>
                        <br>
                        </br>

                        {/* <button><Link to='/google'>Login with Google</Link></button> */}

                        <div class="btn btn-primary payment"><Link to="/google">Login with other Accounts</Link> </div>

             </div></div>

             <br/>
             <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                
                 

                        </div>         
               
        );
    
}
