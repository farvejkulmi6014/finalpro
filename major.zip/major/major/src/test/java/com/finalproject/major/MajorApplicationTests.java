package com.finalproject.major;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MajorApplicationTests {

	@Test
	void contextLoads() {
	}

}
