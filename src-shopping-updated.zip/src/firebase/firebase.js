// import firebase from 'firebase'

// const firebaseConfig = {
//     apiKey: "AIzaSyDrfDvqquhW2lSn7wSQ8g7z8UXZSSyLCYU",
//     authDomain: "ecomm--auth.firebaseapp.com",
//     projectId: "ecomm--auth",
//     storageBucket: "ecomm--auth.appspot.com",
//     messagingSenderId: "61720572807",
//     appId: "1:61720572807:web:f20cc63e59d77623c0d922"
//   };
  
//   // Initialize Firebase
//   const app = initializeApp(firebaseConfig);

//   export {firebase}