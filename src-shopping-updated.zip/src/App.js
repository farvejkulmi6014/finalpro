
// import './App.css';
// import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
// import NavbarComp from './components/NavbarComp';
// import Home from './components/Home'
// import Cart from './components/Cart';
// import {CartProvider} from 'react-use-cart';
// import About from './components/About';
// import Login from './components/login';
// import {
//     BrowserRouter as Router,
//     Switch,
//     Route,
//     Link
//   } from "react-router-dom";
// import Footer from './components/footer';
// import Payment from './components/payments';
// import Contact from './components/Contact';
// import Register from './components/Register';
// import Profile from './components/Profile';
// import Product from './components/Product';




// function App() {
//   return (
    
   
//           <div className="App">
//              <Router>
//      <CartProvider> 
//         <NavbarComp/>

//           <Switch>
//               <Route exact path='/Home' component={Home} />
//               <Route exact path='/About' component={About} />
//               <Route exact path='/Contact' component={Contact} />
//               <Route exact path='/Login'  component={Login}/>
//               <Route exact path='/Register' component={Register} />
//                <Route exact path='/Profile' component={Profile} />
//                <Route exact path='/Cart' component={Cart} />
//                <Route exact path='/Product' component={Product} />
//           </Switch>
    
          
//         <Footer/>
//         </CartProvider> 
        
       

//         </Router>
//    </div>
//   );
// }

// export default App;


import './App.css';
import {CartProvider} from "react-use-cart";
import Footer from './components/footer';
import Register from './components/Register';
import Home from './components/Home';

import Cart from './components/Cart';
import payments from './components/payments'
import login from './components/login'
import NavbarComp from './components/NavbarComp';
import Contact from './components/Contact';
import About from './components/About';
import Product from './components/Product';


import {
BrowserRouter as Router,
Switch,
Route
} from "react-router-dom";function App() {
return (
<div className="App">
<Router>
<CartProvider>
<NavbarComp/>
<Switch>

<Route exact path='/About' component={About}/>
<Route exact path='/payments' component={payments}/>
<Route exact path='/Register' component={Register}/>
<Route exact path='/' component={Home} />
<Route exact path='/login' component={login} />
<Route exact path='/Cart' component={Cart} />
<Route exact path='/Product' component={Product} />


<Route exact path='/Contact' component={Contact}/>

</Switch>
</CartProvider>
<Footer ></Footer >
</Router>
</div>
);
}export default App;

