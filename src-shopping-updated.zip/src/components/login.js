import React, { Component } from 'react';
import axios from 'axios';
import './login.css';

import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';
// import firebase from "firebase"
import StyledFirebaseAuth from "react-firebaseui/StyledFirebaseAuth"

firebase.initializeApp({
    apiKey: "AIzaSyDLoqcbTDMFuurtAyDgVEKZ6qwo0j0Osjk",
    authDomain: "fir-auth-tutorial-ed11f.firebaseapp.com"
  })
  

class Login extends Component {

    state = { isSignedIn: false }
  uiConfig = {
    signInFlow: "popup",
    signInOptions: [
      firebase.auth.GoogleAuthProvider.PROVIDER_ID,
      firebase.auth.FacebookAuthProvider.PROVIDER_ID,
    //   firebase.auth.TwitterAuthProvider.PROVIDER_ID,
    //   firebase.auth.GithubAuthProvider.PROVIDER_ID,
      firebase.auth.EmailAuthProvider.PROVIDER_ID
    ],
    callbacks: {
      signInSuccess: () => false
    }
  }

  componentDidMount = () => {
    firebase.auth().onAuthStateChanged(user => {
      this.setState({ isSignedIn: !!user })
      console.log("user", user)
    })
  }

  render() {
    return (
      <div className="App">
        {this.state.isSignedIn ? (
          <span>
            <div>Signed In!</div>
            <button onClick={() => firebase.auth().signOut()}>Sign out!</button>
            <h1>Welcome {firebase.auth().currentUser.displayName}</h1>
            <img
              alt="profile picture"
              src={firebase.auth().currentUser.photoURL}
            />
          </span>
        ) : (
          <StyledFirebaseAuth
            uiConfig={this.uiConfig}
            firebaseAuth={firebase.auth()}
          />
        )}
      </div>
    )
  }












    

//     constructor(props) {
//         super(props);
//         this.state = {
//             password: '',
//             emailid:' '
//         }
//     }

//     handleChange = event => {
//         this.setState({ [event.target.name]: event.target.value })
//     }
//     handleSubmit = event => {
//          event.preventDefault()
//         axios.post('http://localhost:8088/save', this.state)
//             .then(res => {
//                 console.log(res.data)
//             })
//             .catch(err => {
//                 console.log(err)
//             })
//     }
//     render() {
//         const { password,emailid } = this.state
//         return (
//             <div>
//                 <form onSubmit={this.handleSubmit}>
                
                  
//                     <div>
//                         <label htmlFor="ci">emailid</label>
//                         <input type="text" name="emailid" id="ci" value={emailid} onChange={this.handleChange} />
//                     </div>
//                     <br />
//                     <div>
//                         <label htmlFor="pa">password</label>
//                         <input type="text" name="password" id="pa" value={password} onChange={this.handleChange} /> <br />
//                         <button type='submit'>Login</button>
//                     </div>

//                     {/* <div>
//                         <input type="submit" value="login" />
//                         <input type="reset" value="clear" />
//                     </div> */}

                    
// {/* 
// <div class="container">
// <div class="screen">
// <div class="screen__content">
// <form class="login">
// <div class="login__field">
// <i class="login__icon fas fa-user"></i>

// <input type="text" class="login__input" placeholder="User name / Email"/>
// </div>
// <div class="login__field">
// <i class="login__icon fas fa-lock"></i>
// <input type="password" class="login__input" placeholder="Password"/>
// </div>
// <button class="button login__submit">
// <span class="button__text">Log In Now</span>
// <i class="button__icon fas fa-chevron-right"></i>
// </button>
// </form>
// <div class="social-login">
// <h3>log in via</h3>
// <div class="social-icons">
// <a href="#" class="social-login__icon fab fa-instagram"></a>
// <a href="#" class="social-login__icon fab fa-facebook"></a>
// <a href="#" class="social-login__icon fab fa-twitter"></a>
// </div>
// </div>
// </div>
// <div class="screen__background">
// <span class="screen__background__shape screen__background__shape4"></span>
// <span class="screen__background__shape screen__background__shape3"></span>
// <span class="screen__background__shape screen__background__shape2"></span>
// <span class="screen__background__shape screen__background__shape1"></span>
// </div>
// </div>
// </div> */}
//                 </form>
                
//             </div>
//         );
//     }
}
export default Login;