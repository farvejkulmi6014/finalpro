import React, { Component } from "react";
import './About.css';
 class About extends Component{
    render(){
        return(
           <div>
  
 
           </div>
        )
    }
}

export default About;