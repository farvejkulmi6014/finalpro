// import React, { Component } from "react";
//  // import { Button, Form, FormControl } from "react-bootstrap";
// import { Navbar,Nav,NavDropdown,Form,FormControl,Button} from "react-bootstrap";
// import {
//     BrowserRouter as Router,
//     Switch,
//     Route,
//     Link
//   } from "react-router-dom";
// import About from "./About";
// import Contact from "./Contact";
// import Home from "./Home";
// import Login from "./login";
// import Register from "./Register";
// import Profile from "./Profile";
// import Cart  from './Cart'
// import Product from "./Product";
  

// export default class NavbarComp extends Component{
//     render(){
//         return(
//             <Router>
//             <div>
//                 <Navbar bg="dark" variant={"dark"} expand="lg">
//     <Navbar.Brand as={Link} to={'/Home'}>Bags-Cart</Navbar.Brand>
//     <Navbar.Toggle aria-controls="basic-navbar-nav" />
//     <Navbar.Collapse id="basic-navbar-nav">
//       <Nav className="me-auto">
      
//         <Link to={'/Home'} >Home</Link>

//         <Link to={'/About'}>About</Link>

//         <Link to={'/Contact'}>Contact Us</Link>
//         <Nav.Link as={Link} to={'/Product'} >Products</Nav.Link>

//         <NavDropdown title="Login/Register" id="basic-nav-dropdown">

//           <NavDropdown.Item as={Link} to={"/Login"}>Login</NavDropdown.Item>

//           <NavDropdown.Item  as={Link} to={"/Register"}>Register</NavDropdown.Item>

//           <NavDropdown.Item as={Link} to={"/profile"}>Profile</NavDropdown.Item>
//           <NavDropdown.Divider />
//           <NavDropdown.Item as={Link} to={'/Cart'}>Cart</NavDropdown.Item>
//         </NavDropdown>
//       </Nav>
//       <Form inline>
//           <FormControl type="text" placeholder="Search" className="mr-sm-2" /><Button variant="outline-success"> Search </Button>
//       </Form>
//     </Navbar.Collapse>
// </Navbar>
//    </div>
//     {/* <div>
//       <Switch> 
//               <Route exact path='/Home' component={Home} />
//               <Route exact path='/About' component={About} />
//               <Route exact path='/Contact' component={Contact} />
//               <Route exact path='/Login'  component={Login}/>
//               <Route exact path='/Register' component={Register} />
//                <Route exact path='/Profile' component={Profile} />
//                <Route exact path='/Cart' component={Cart} />
//                <Route exact path='/Product' component={Product} />
//         </Switch>
          
//     </div> */}
//    </Router> 
//         );
//     }
// }




import React from "react";
// import { FaHome,FaShoppingBasket,FaPhone} from 'react-icons/fa';
import {
Link
} from "react-router-dom";



function Navbar(){
// const{products}=data;
return(
<div>



<nav class="navbar navbar-expand-lg navbar navbar-dark bg-dark">
<div class="container-fluid">
<a class="navbar-brand" href="#"><h3>Ecommerce</h3></a>
<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarSupportedContent">
<ul class="navbar-nav me-auto mb-2 mb-lg-0">
<li class="nav-item">
<Link to={'/'} class="link">Home</Link>
</li>
<li class="nav-item">
<Link to={'/About'} class="link">About Us</Link>
</li>
<li class="nav-item">
{/* <a class ="nav-link" Link to="/Login">Login</a> */}

<Link to={'/login'} class="link">Login</Link>

</li>
<li class="nav-item">
<Link to={'/Cart'} class="link">Cart</Link>
</li>

<li class="nav-item">
<Link to={'/Product'} class="link">Products</Link>
</li>





<li class="nav-item">
<Link to={'/Contact'} class="link">Contact Us</Link>
</li>



</ul>
<form class="d-flex">
<input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
<button class="btn btn-outline-success" type="submit">Search</button>
</form>



</div>
</div>
</nav>
</div>



// <Router>
// <div>
// <ul>
// <li>
// <Link to="/">Home</Link>
// </li>
// <li>
// <Link to="/Login">login</Link>
// </li>
// </ul>
// <hr />
// <Switch>
// <Route exact path='/' component={Home}/>
// <Route exact path='/Login' component={Login} />
// </Switch>
// </div>
// </Router>
);
}
export default Navbar;