import React from "react";
import { useCart } from "react-use-cart";
import payments from "./payments";
// import { browserHistory, Router } from "react-router"
// // import { Router, browserHistory } from 'react-router';
// import { createBrowserHistory } from 'history'

import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
  } from "react-router-dom";





const Cart=()=>{
    // onNavigatePayment=() => {
    //     browserHistory.push("/payments");
    // }

    const  {
        isEmpty,
        totalUniqueItems,
        items,
        totalItems,
        cartTotal,
        updateItemQuantity,
        removeItem,
        emptyCart,

    }=useCart();
    if(isEmpty) return <h1 className="text-center"> Your Cart is Empty </h1>
    return(
        <Router>

       
        <section className="py-4 container"> 
        <div className="row justify-content-center">
            <div className="col-12">
                <h5>Cart ({totalUniqueItems}) total Items:({totalItems})</h5>
                <table className="table table-light table-hover m-0"> 
                <tbody>
                {items.map((item,index)=>{
                    return(
                    <tr key={index}>
                        <td>
                            <img src={item.img} style={{height:'6rem'}} /> 
                        </td>
                        <td>{item.titel}</td>
                        <td>{item.price}</td>
                        <td>Quntity ({item.quantity})</td>
                        <td>
                            <button 
                            className="btn btn-info ms-2"
                            onClick={()=> updateItemQuantity(item.id,item.quantity - 1)}
                            >-</button>
                            <button 
                            className="btn btn-info ms-2"
                            onClick={()=> updateItemQuantity(item.id,item.quantity + 1)}
                            >+</button>
                            <button  className="btn btn-danger ms-2"
                            onClick={()=>removeItem(item.id)}
                            >Remove Item</button>
                        </td>
                    </tr>
                    )
                })}
                </tbody>
                </table>
            </div>
            <div className="col-auto ms-auto">
                <h2>Total price: $ {cartTotal}</h2>
            </div>
            <div className="col-auto">
                <button className="btn btn-danger m-2"
                onClick={()=>emptyCart()}
                > Clear Cart</button>
           
            {/* <button><Link to='/payments' target='payments'> Click Me  </Link></button> */}
           
               
                {/* <button  className="btn btn-primary m-2">Buy now</button> */}

                <Link to={'/payments'}><button>Buy Now</button></Link>

            </div>
            
        </div>
        {/* <div>
      

         <Switch>
              <Route exact path='/payments' component={payments} />
            
          </Switch>
    </div>  */}
        </section>
        
        
         </Router>
        //  <Nav.Link as={Link} to={'/Home'}>Home</Nav.Link>
    )
}

// onNavigatePayment(); {
//     browserHistory.push("/payments")
// }


export default Cart;