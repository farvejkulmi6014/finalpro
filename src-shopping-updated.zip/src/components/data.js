import img1 from './img/img1.png';
import img2 from './img/img2.png';
import img3 from './img/img3.png';
import img4 from './img/img4.png';
import img5 from './img/img5.png';
import img7 from './img/img7.png';
import img8 from './img/img8.png';
import img9 from './img/img9.png';

const data={
    productData:[
        {
            id:1,
            img:img1,
            title: "Gril Rainbow School bag",
            desc:"very easy carry the bag and light weight ",
            price:46,
        },
        {
            id:2,
            img:img2,
            title: " Women Gray Hand bags",
            desc:" ",
            price:46,
        },
        {
            id:3,
            img:img3,
            title: "Paradias School bag",
            desc:" ",
            price:46,
        },
        {
            id:4,
            img:img4,
            title: " schoolbag",
            desc:" ",
            price:46,
        },
        {
            id:5,
            img:img5,
            title: "Hand and sling bag",
            desc:" ",
            price:46,
        },
        {
            id:6,
            img:img7,
            title: "hand bag",
            desc:" ",
            price:46,
        },
        {
            id:7,
            img:img8,
            title: "bag",
            desc:" ",
            price:46,
        },
        {
            id:8,
            img:img9,
            title: "Men Laptop bag",
            desc:" ",
            price:46,
        },

    ]
}

export default data;