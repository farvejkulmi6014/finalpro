import React, { Component } from "react";
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
  } from "react-router-dom";
  import Home from "./Home";
  import Contact from "./Contact";
  import About from "./About";
  import Login from "./login";
  import Register from "./Register";
  import payments from "./payments";
  
class Profile extends Component{

    render(){
        return(
            <Router>
            <div className='App'>
              <h1> My Profile</h1>
              <ul className='Link' type='none'>
                <li> <Link to={'/Home'}>Home</Link></li>
                <li> <Link to={'/About'}>About</Link></li>
                <li> <Link to={'/Contact'}>Contact</Link></li>
                <li><Link to={'/Login'}>Login</Link></li>
                <li><Link to={'/Register'}>Register</Link></li>
              </ul>
              <hr/>
              <Switch>
                    <Route exact path='/Home' component={Home} />
                    <Route exact path='/payments' component={payments} />
                    <Route exact path='/About' component={About} />
                    <Route exact path='/Contact' component={Contact} />
                    <Route exact path='/Login' component={Login} />
                    <Route exact path='/Register' component={Register} />
              </Switch>
            </div>
          </Router>
        )
    }
}

export default Profile;