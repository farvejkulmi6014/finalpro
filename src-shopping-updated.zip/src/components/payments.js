import React from 'react';
import App from '../App';


const Payment=()=>{

    return(
        <div>
            <h1>hello</h1>
            <h1>hello</h1>
            <h1>hello</h1>
            <h1>hello</h1>
            <h1>hello</h1>
        </div>
    )

}

export default Payment;