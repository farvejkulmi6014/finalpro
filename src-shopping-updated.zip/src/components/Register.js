import React, { Component } from 'react';
import axios from 'axios';
import './Register.css';
// import { Button, Form, FormControl } from "react-bootstrap";

class Register extends Component {
    constructor(props) {
        super(props);
        this.state = {
            id: 0,
            name: '',
            password: '',
            emailid:' ',
            mobilenumber: ' '
        }
    }

    handleChange = event => {
        this.setState({ [event.target.name]: event.target.value })
    }
    handleSubmit = event => {
        event.preventDefault()
        axios.post('http://localhost:8088/send', this.state)
            .then(res => {
                console.log(res.data)
            })
            .catch(err => {
                console.log(err)
            })
    }
    render() {
        const { id, name, password,emailid,mobilenumber } = this.state
        return (
            <div >
                <form onSubmit={this.handleSubmit}>
                    <div>
                        <label htmlFor="Id" >ID</label>
                        <input type="text" name="id" id="Id" value={id} onChange={this.handleChange} />
                    </div>
                    <br />
                    <div>
                        <label htmlFor="na">Name</label>
                        <input type="text" name="name" id="na" value={name} onChange={this.handleChange} />
                    </div>
                    <br />
                    <div>
                        <label htmlFor="ci">emailid</label>
                        <input type="text" name="emailid" id="ci" value={emailid} onChange={this.handleChange} />
                    </div>
                    <br />
                    <div>
                        <label htmlFor="pa">password</label>
                        <input type="text" name="password" id="pa" value={password} onChange={this.handleChange} />
                    </div>
                    <br />
                    <div>
                        <label htmlFor='mo'>Mobile</label>
                        <input type="text" name="mobilenumber" id="mo" value={mobilenumber} onChange={this.handleChange} />
                    </div>
                    <br />
                    <div>
                        <input type="submit" value="register" />
                        <input type="reset" value="clear" />
                    </div>
{/* 
         <div class="form-floating">
          <input type="Id" class="form-control" id="Id" placeholder="name"/>
          <label for="Id">Enter Id</label>
        </div>
        <br></br>

        <div class="form-floating">
        <input type="text" class="form-control" id="name"  placeholder="name"/>
        <label htmlFor="name">Enter Full Name</label>
        </div>
        <br></br>

        <div class="form-floating">
        <input type="emailid" class="form-control" id="emailid" placeholder="name"/>
          <label for="emailid">Enter Email ID</label>
        </div>
        <br></br>

        <div class="form-floating">
        <input type="password" class="form-control" id="password" placeholder="name"/>
          <label for="password">******</label>
        </div>
        <br></br>

        <div class="form-floating">
        <input type="mobilenumber" class="form-control" id="mobilenumber" placeholder="name"/>
          <label for="mobilenumber">Enter Contact Number</label>
        </div>
        <br></br>

        <div>
                        <input type="submit" value="register" />
                        <input type="reset" value="clear" />
                    </div>  */}

    

        
                </form>
            </div>
        );
    }
}
export default Register;