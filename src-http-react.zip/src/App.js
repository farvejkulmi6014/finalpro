import logo from './logo.svg';
import './App.css';
import Students from './component/student';

function App() {
  return (
   <Students/>
  );
}

export default App;
