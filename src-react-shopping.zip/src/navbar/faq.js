import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';

function FAQ(){
    return(
        <div>
          <h1>faq</h1>
  
        </div>
    )
};

export default FAQ;