import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';

function Cart(){
    return(
        <div>
          <h1>cart </h1>
  
        </div>
    )
};

export default Cart;