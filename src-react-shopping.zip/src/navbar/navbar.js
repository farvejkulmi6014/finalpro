import React from "react";
import './navbar.css';
import {Navbar, Nav} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from 'react-router-dom';
import About from "./about";
import Cart from "./cart";
import Home from "./home";
import Product from "./products";
import FAQ from "./faq";

function NavbarComp(){
    return(
    <Router>
      <div class="container">
      <header class="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 mb-4 border-bottom">
        <a href="/" class="d-flex align-items-center col-md-3 mb-2 mb-md-0 text-dark text-decoration-none">
          <svg class="bi me-2" width="40" height="32" role="img" aria-label="Bootstrap"></svg>
        </a>
  
        <ul class="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR-Ur5t_tg3BxCzyZ4HWJNv_Du4pr_nzqHn-Q&usqp=CAU"></img>
    <Navbar bg="light" variant="light">
    {/* <Navbar.Brand href="#home">Navbar</Navbar.Brand> */}
      <Nav className="me-auto">
      <Nav.Link as={Link} to={"/home"}>Home</Nav.Link>
      <Nav.Link as={Link} to={"/products"}>Products</Nav.Link>
      <Nav.Link as={Link} to={"/cart"}>Cart</Nav.Link>
      <Nav.Link as={Link} to={"/faq"}>FAQs</Nav.Link>
      <Nav.Link as={Link} to={"/about"}>About us</Nav.Link>
    </Nav>
  </Navbar>
        </ul>
  
        <div class="col-md-3 text-end">
          <button type="button" class="btn btn-outline-primary me-2">Login</button>
          <button type="button" class="btn btn-primary">Sign-up</button>
        </div>
      </header>
    </div>
    <div>
    <Switch>
          <Route path="/about">
            <About />
          </Route>
          <Route path="/home">
            <Home />
          </Route>
          <Route path="/products">
            <Product />
              </Route>
            <Route path="/faq">
            <FAQ/>
          </Route>
          <Route path="/cart">
            <Cart/>
          </Route>
        </Switch>
    </div>
    </Router>

    )};


    
export default NavbarComp;

