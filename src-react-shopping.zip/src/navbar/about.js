import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';

function About(){
    return(
        <div>
          <h1>hi</h1>
  
        </div>
    )
};

export default About;