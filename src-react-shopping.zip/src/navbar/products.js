import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import './products.css';

function Product(){
    return(
        <div>
          <h1>Choose product of your choice </h1>
          <div class="product">
    <div class="product-img">
        <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhUSDxIVFRAVFRAVDxUVFQ8PDxUVFRUWFhUVFRUYHSggGBolHRUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OFxAQFysmHyUtKy01LzAuLi0rLS0tKy0tLS0tKystKystKy0tLS0tNSstLS0yLSstLS0tLS4tKy0rK//AABEIAOEA4QMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAAAQIDBAUGB//EADwQAAIBAQUDCQYEBQUAAAAAAAABAhEDBAUhMUFRcRIiMmGBkaGxwRUjM0Jy0QYTUmJzosLh8WOCkrLw/8QAGQEBAQEBAQEAAAAAAAAAAAAAAAEEAwIF/8QAJxEBAAICAQIFBQEBAAAAAAAAAAECAxEEMTISEyFBURQiQmFxgTP/2gAMAwEAAhEDEQA/APqgAKAAAAAAAAAKWtrGKrJpLryOVescisrNV63ku490x2v0h5teK9XXbNT2nY8v8v8AMjy6J0eWT3PTYecvF8nN1lJ9WxLLccG929LzJNPOMKPVaU0NVeJ8y4zn+IfTCTwthfJR6E2upSa8Dbhittsm/wCVnmeJb2lYzx8PXg8jLFbf9b/lRqXi/wA3lK0b4yb8BHEt7yTnj4euvOJ2Nm1GdpFSk0ktXV76adpsWdopKsWmup1Pmlvb1tIJJtucaN81arZrtO5C3lF1i2n1Hu3EjXpPq8xn+YeyBwbrjrWVoq9ayfcdi73qE1WEk+rb3GW+K1OsO1b1t0ZgAc3sAAAAAAAAAAAAAAAAAKzmkm3klmwItbVRVZOiOLe8celkqdbzfdsNHGr25S1yjotiT28TT5VaPf5n0MXGiI3ZkvmmZ1C9tbSk6ybb6yiRJJp047QcnF4UtYT2NOL4p1Xn4HXZgvt2/Mg4/MqOL3NafbtZSFIUazMllYxlJJ0S2uladho3K2qqSyksmnqmjdhIsoy291hGlGnvypQwNUWRknPI1ba0ohBLBYrlW0f21k+zTxodRvPuNPDLDkpzl0pab1HZ369xuJf3JKlBCTWadH4kgDqXTGpxynzlv0l/c7d2vUbRVg671tXE8faSoq9hlulvKzfKi89vX1GbLxq2jdfSXWmaY9JeyBhutupxqu3qZmPnTGp1LZE7AAAAAAAAAAAAAA4+MXqtILSvO7Nhu3+88iNFq/BHnLW0q69xr42Lf3Sz5sn4w1sQzfaa9xn0o7mvH/Bs2hpXBe8tF1Wf9Z9COjL7t+hFCQQGQywA1LzdFN8qL5M9r39Ul6mJWdotY160019zecSM9/ehtWlJTfyvtovMtZXXbOj3L5e3ebVH/wCRaMBtERVdS1CQQRQgkUA1sSnRR+uPqZoZ5933NLHpUhB/6kV3p0Nyx0R69h0sOvvIln0XRS+56WMq5o8bE7eD3z5JP6fsYuTi390NGHJr7ZdgAGFqAAAAAAAADHbWqiqsu2cHE75ynRdFHXDj8dv055L+GGtfby5Ns1WyWyD6kRqNMUqNGhhy95bP+F/WdCWhp4braP8Ael3RT9S+yN0AEEkEgCCSSAFBQkAQCaEUAgUBIHL/ABEvdxe60svOnqb9joamPqti+qVi+60ibdg8iqyVLWc6MqCD0+G3vlxz6S1+5uHlLreHCSa1Xitx6ewtlOKktGfNz4vBO46NmK/ij16sgAODqAAAAauIXr8uOXSfR+5a1m06hJmIjctTFr5TmR1+Z+hxZMtKdTGfVx0ildQw3tNp2gAHt4VnoamFrmz/AIkvKKNuZr4auY+udp/2p6F9htAkggkgmgAIEokCoJYAigJICoRNCEWCNHGY+5n1JP8A4tP0MlzfNXAvfoVs5rfCXkzBhvQXAo3CCQQQdLCr7yHR9F+HWc1kpnm9YtGpeq2ms7h7FMk5WD3yq5EnmtOB1T5V6TSdS3VtFo3AADy9ByMXucm+XHPet3A65B6peaTuHm1YtGpeQoQd/EMMU845S8HxODa2bi6SVHuPpYstbx+2O+OaoIJTFDq8MdpoYcM+FHrc33zk/UzW2j4Mw4TGljZr9sfHMo2gSyGQSQSiGARYqiwEAkACGSQwIiSViWCK2vRfB+Rr3SFIqmmqNpmC69CP0x8ijMQyxUgFWWUa6dx1sPwvbPu2I55MtaR6vdKTafRr4ZdJtqWi8WejiVhBLQufNyZJvO5baUisagAB4egAADWvlzjaKklnse1GyCxMxO4SY28pfblKzeemyWztNflHsLSzUlRqqOFfMFdfdvmvVPVcDbi5MT6XZr4ddrlflynzY6vuRaFlyEofpSj3ZHpbhcI2a69u84F46cvql5nTFm8y066PF8fhiGMAg7uSyIZKAVCLIhEoCCQRUCSGSQwIiWZVFmEQUs7vKzioz3ZNaNGQ9DY3eM7NKS2I45cvl6+HXHTx7ecL2Ng5ui7dyN/2TLlU+XftZ17tdYwWSOeTkxEfa90wzPVrXHDlHN6nQSJBhmZmdy0xER6QAAigAAAAAAAAAAHkbbpS4vzPXHkLR5vizZxOtmfkeypABuZVkQyUQyKFipYCASQBJVssVYERLsoi5UQemw98xcEeZPS4Z8OPBGPl9IaOP1ltgAwtQAAAAAAAAAAAAAAACGeQtD109HwZ5G01NvE/Jm5HsqRUllUbWZkRBJDCkSxVFkRBkEsgKIMkiQFEZDGi5UD0mFfDXBHmj0eEP3aMnL7YaMHWW8ADA1AAAAAAAAAAAAAAAAKW3RfB+R5F6nrLy+ZL6ZeR5I28TpLNn6whkRJkRFm1nZCGSQwIRZFUWQRLKlmVIqSJEkSApEyIxIyoqQg9Fg3w0edPQYK/d9/mZeX2R/XfB3OiAD57WAAAAAAAAAAAAAAAAw3z4c/pl5Hk4nqr/wDDn9MvI8tA3cTtllz9YVkRATFmbGdkKsuykgoi6MaMiCDKssVbIqURIlEMDEjLExRMsSy8wM7+Bvmd/mcBndwJ8ztZl5XZ/rRg7nUAB89rAAAAAAAAAAAAAAAAa2I/Cn9LPL2Z6fE/hT4eqPMWZv4nbP8AWXP3QpaCzImxZGtnZmUkWkUmFEZEYosyoSkBVlmUIqUJBBlRhiZYmFamaIlISzuYC+a+LOEzt4B0XxfoZuV2NGDudcAHzmsAAAAAAAAAAAAAAABp4s/dT7PNHmo6Ho8ZfuZf7fNHnJaI38Xsn+sufuYpk2JWZewNfszskiky8jHMKrAz1MFmZxKQhlGyzKMC6IkEwwMCeZmiYG8zNAspCz0O1+H3k+PojiPRnZ/DzyfH0M3J/wCcu+HudoAHzWwAAAAAAAAAAAAAAABoY18J8Y+Z5y0kervdgpx5L6vA5jwNP5n4fY14M1aV1Lhlx2tO4cGTMlidpYFHa33ossFS0b7zt9VRy8izjSZjmzuSwX9z8AsEW1vwL9TjPJs4EGbB2FgcOvvLywdb2T6qn7PIs4TZQ7vsVb34D2Kt78B9VQ8iziINnb9ire/Ah4Kv1Pw+w+qxnkWedk8zNZM7XsKO1vw+xlWCxSyb7yzy6HkWcKMjr/h75uJZYGv1Pw+xuXC4/l1zrU45s9bVmIdMeO1bblvAAxtAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/9k=" alt="tshirt"></img>
    </div>
    <div class="product-listing">
    <div class="content">
        <h1 class="name">T-Shirt</h1>
        <p class="info">Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque laborum optio natus quibusdam ea nam odit vitae id unde officia.</p>
        <p class="price">$ 9.99</p>
        <div class="btn-and-rating-box">
            <div class="rating">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmFTnkZJrixLb3T1FID3463dWSdqxHCczUNw&usqp=CAU" alt=""></img>
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmFTnkZJrixLb3T1FID3463dWSdqxHCczUNw&usqp=CAU" alt=""></img>
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmFTnkZJrixLb3T1FID3463dWSdqxHCczUNw&usqp=CAU" alt=""></img>
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmFTnkZJrixLb3T1FID3463dWSdqxHCczUNw&usqp=CAU" alt=""></img>
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmFTnkZJrixLb3T1FID3463dWSdqxHCczUNw&usqp=CAU" alt=""></img>
            </div>
            <button class="btn">buy now</button>
        </div>
    </div>
</div>
    </div>
    <br></br>

    <div class="product">
    <div class="product-img">
      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRku4zBb-v4OEgTv1tFvgAEGw5NpBl0iVk1xQ&usqp=CAU"></img>
       </div>
    <div class="product-listing">
    <div class="content">
        <h1 class="name">Pant</h1>
        <p class="info">Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque laborum optio natus quibusdam ea nam odit vitae id unde officia.</p>
        <p class="price">$ 10.56</p>
        <div class="btn-and-rating-box">
            <div class="rating">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmFTnkZJrixLb3T1FID3463dWSdqxHCczUNw&usqp=CAU" alt=""></img>
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmFTnkZJrixLb3T1FID3463dWSdqxHCczUNw&usqp=CAU" alt=""></img>
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmFTnkZJrixLb3T1FID3463dWSdqxHCczUNw&usqp=CAU" alt=""></img>
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmFTnkZJrixLb3T1FID3463dWSdqxHCczUNw&usqp=CAU" alt=""></img>
               
            </div>
            <button class="btn">Buy now</button>
        </div>
    </div>
</div>
    </div>
    <br></br>

    <div class="product">
    <div class="product-img">
      <img src="https://media.istockphoto.com/photos/mens-shirt-picture-id488160041?k=20&m=488160041&s=612x612&w=0&h=OH_-skyES8-aeTvDQHdVDZ6GKLsqp6adFJC8u6O6_UY="></img>
       </div>
    <div class="product-listing">
    <div class="content">
        <h1 class="name">Shirt</h1>
        <p class="info">Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque laborum optio natus quibusdam ea nam odit vitae id unde officia.</p>
        <p class="price">$ 23.56</p>
        <div class="btn-and-rating-box">
            <div class="rating">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmFTnkZJrixLb3T1FID3463dWSdqxHCczUNw&usqp=CAU" alt=""></img>
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmFTnkZJrixLb3T1FID3463dWSdqxHCczUNw&usqp=CAU" alt=""></img>
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmFTnkZJrixLb3T1FID3463dWSdqxHCczUNw&usqp=CAU" alt=""></img>
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmFTnkZJrixLb3T1FID3463dWSdqxHCczUNw&usqp=CAU" alt=""></img>
               
            </div>
            <button class="btn">Buy now</button>
        </div>
    </div>
</div>
    </div>


</div>
    )
};

export default Product;