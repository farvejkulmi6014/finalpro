import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';

function Home(){
    return(
        <div>
          <h1>home</h1>
  
        </div>
    )
};

export default Home;