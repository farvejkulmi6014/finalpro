import React from 'react';
import './App.css';
import About from './navbar/about';
import FAQ from './navbar/faq';
import Image from './navbar/images';
import NavbarComp from './navbar/navbar';
import Product from './navbar/products';


function App() {
  return (
    <div>
       <NavbarComp/>
       {/* <Product/>
       <About/>
       <FAQ/> */}

      
    </div>
  );
}

export default App;
