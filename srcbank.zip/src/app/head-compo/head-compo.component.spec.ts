import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HeadCompoComponent } from './head-compo.component';

describe('HeadCompoComponent', () => {
  let component: HeadCompoComponent;
  let fixture: ComponentFixture<HeadCompoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HeadCompoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HeadCompoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
